import openpyxl
import shutil
import time


class Speed_Reader:
    def __init__(self, input_num):
        # 원본 파일 경로와 복사될 파일 경로 지정
        original_file_path = "C:/Users/jhj/Desktop/230326/intersection.xlsx"
        copied_file_path = "C:/Users/jhj/Desktop/230326/copy.xlsx"
        try:
            shutil.copy(original_file_path, copied_file_path)
            time.sleep(1)
        except Exception as e:
            print(e)

        self.wb = openpyxl.load_workbook(copied_file_path)
        self.car_ws = self.wb['speed']
        self.bus_ws = self.wb['bus_speed']

        # 결과를 저장할 딕셔너리
        self.data_dict = {}

    def copy_row(self, input_num):
        copied_row_data = {}

        for ws in (self.car_ws, self.bus_ws):
            for row in ws.iter_rows(min_row=input_num, max_row=input_num, values_only=True):
                for col_num, cell_value in enumerate(row, start=ws.min_column):
                    col_letter = openpyxl.utils.get_column_letter(col_num)
                    if col_letter != 'A' and cell_value is not None:
                        if ws.title == 'bus_speed':
                            col_letter = col_letter.lower()
                        copied_row_data[cell_value] = col_letter

        # 복사된 행의 값을 저장
        self.data_dict = copied_row_data

    def get_result_dict(self):
        result_dict = {key: value for key, value in self.data_dict.items()}
        return result_dict

