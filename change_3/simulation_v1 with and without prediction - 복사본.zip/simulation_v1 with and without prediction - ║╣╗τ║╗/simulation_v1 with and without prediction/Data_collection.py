import Cpu_num
import X_num
import Y_num
import Speed_num
import array
import numpy as np
import time

class Data_Reader():
    def __init__(self, input_num):
        self.input_num = input_num

        cpu_reader = Cpu_num.Cpu_Reader(input_num)
        cpu_reader.copy_row(input_num)  # 행 복사
        cpu_result = cpu_reader.get_result_dict()
        self.Cpu_list = array.array('f', cpu_result.keys())

        # Y_num.Y_Reader 객체 생성 및 결과 리스트 가져오기
        y_reader = Y_num.Y_Reader(input_num)
        y_reader.copy_row(input_num)  # 행 복사
        y_result = y_reader.get_result_dict()
        self.Y_list = array.array('f', y_result.keys())

        # X_num.X_Reader 객체 생성 및 결과 리스트 가져오기
        x_reader = X_num.X_Reader(input_num)
        x_reader.copy_row(input_num)  # 행 복사
        x_result = x_reader.get_result_dict()
        self.X_list = array.array('f', x_result.keys())

        self.count = len(self.Cpu_list)


        # Speed_num.Speed_Reader 객체 생성 및 결과 리스트 가져오기
        speed_reader = Speed_num.Speed_Reader(input_num)
        speed_reader.copy_row(input_num)  # 행 복사
        speed_result = speed_reader.get_result_dict()

        self.Speed_list = array.array('f')
        self.Char_list = array.array('b')

        for key, value in speed_result.items():
            self.Speed_list.append(key)
            self.Char_list.append(ord(value))  # 문자열을 정수로 변환하여 추가

    def get_min_index(self, lst):
        min_value = min(lst)
        min_index = lst.index(min_value)
        return min_index

    def get_min_speed_index(self):
        return self.get_min_index(self.Speed_list)

    def get_value_by_key(self, key):
        index = self.Speed_list.tolist().index(key)
        value = self.Char_list[index]
        if isinstance(value, int):
            value = chr(value)
        return value

# # Data_Reader 객체 생성
# reader = Data_Reader(3)
#
# # X_list에서 가장 작은 값이 들어있는 키(key) 출력
# min_speed_index = reader.get_min_speed_index()
# min_speed_key = reader.Speed_list[min_speed_index]
# print("Minimum x key:", min_speed_key)
#
# # 해당 키(key)값에 대한 value값 출력
# min_x_value = reader.get_value_by_key(min_speed_key)
