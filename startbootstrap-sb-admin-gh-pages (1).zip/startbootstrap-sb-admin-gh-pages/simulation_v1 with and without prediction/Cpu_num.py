import openpyxl
import time

class Cpu_Reader:
    def __init__(self, input_num):
        # 엑셀 파일 열기
        self.wb = openpyxl.load_workbook("C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/파일_13.xlsx")

        self.Car_Cpu = self.wb['car_cpu']
        self.Bus_Cpu = self.wb['bus_cpu']
        # 시작 열의 인덱스
        self.start_col = 2

        self.start_row = input_num

        # 결과를 저장할 딕셔너리
        self.result_dict = {}

    def get_result_dict(self):
        result_dict = {}  # 빈 딕셔너리 생성

        # Iterate over both Car_X and Bus_X sheets
        for sheet in [self.Car_Cpu, self.Bus_Cpu]:
            for col_idx, cell in enumerate(sheet[self.start_row], self.start_col):
                if col_idx > self.start_col:  # Skip the first column (A)
                    if cell.value is not None:
                        col_letter = openpyxl.utils.get_column_letter(col_idx - 1)  # Decrement col_idx by 1
                        # Get the vehicle type (car or bus) from the sheet name
                        vehicle_type = sheet.title.lower()
                        col_name = f"{vehicle_type}_{col_letter}"
                        result_dict[col_name] = cell.value

        # 결과 딕셔너리 반환
        return result_dict


# input_row_number = 4
# x_reader = Cpu_Reader(input_row_number)
# result_dict = x_reader.get_result_dict()
# print(result_dict)
