import numpy as np
import random
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from keras import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from environment1 import CreateClusEnv
from Data_collection import Data_Reader
import Cpu_num
import openpyxl
# Define the Deep Q-Learning agent
class DQNAgent:
    def __init__(self, state_size, action_size, learning_rate=0.001, discount_factor=0.99, exploration_rate=1, exploration_decay=0.999, batch_size=5):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.exploration_rate = exploration_rate
        self.exploration_decay = exploration_decay
        self.batch_size = batch_size
        self.memory = []
        self.model = self._build_model(self.state_size, self.action_size)
        self.target_network=self._build_model(self.state_size, self.action_size)

    def _build_model(self,state_size, action_size):
        model = Sequential([
            Dense(64, input_dim=state_size, activation='relu'),
            Dense(64, activation='relu'),
            Dense(64, activation='relu'),
            Dense(action_size, activation='linear')
        ])
        model.compile(loss='mse', optimizer=Adam(lr=self.learning_rate))
        return model

    def alighn_target_model(self):
        self.target_network.set_weights(self.model.get_weights())

    def store(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def act(self, state):
        if np.random.rand() <= self.exploration_rate:
            return random.randrange(self.action_size)
        q_values = self.model.predict(state)
        return np.argmax(q_values[0])

    def rebuild_model(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.model = self._build_model(state_size, action_size)
        self.target_network = self._build_model(state_size, action_size)

    # 성공률 데이터 입력 함수

    def retrain(self,number):
         if len(self.memory) < self.batch_size:
             return
         samples = random.sample(self.memory, self.batch_size)
         for state, action, reward, next_state, done in samples:
             # Ensure the state and next_state have the correct shapes (state_size and action_size)
             #print("Retrain:::::::",len(state[0]),len(next_state[0]))
             length1=len(state[0])
             length2=len(next_state[0])
             #print("Retrain:::::::",length1,length2)
             #print("RETRAIN::::::",state.shape[0],next_state.shape[0])
             while(length1<number):
                state = np.append(state, 0)
                length1+=1
             while(length2<number):
                next_state = np.append(next_state, 0)
                length2+=1
             print("Retrain:::::::",state,next_state)
             state=np.reshape(state,[1,number])
             next_state=np.reshape(next_state,[1,number])
             target = self.model.predict(state)
             if done:
                 target[0][action] = reward
             else:
                 q_next = np.max(self.target_network.predict(next_state)[0])
                 target[0][action] = reward + self.discount_factor * q_next
             self.model.fit(state, target, epochs=1, verbose=0)
         self.exploration_rate *= self.exploration_decay
    

env=CreateClusEnv()


batch_size=5
num_of_episodes=20
timesteps_per_episode=20
#agent.q_network.summary()
ep_reward=[0]*400
success_rate=0
rewards=[]
count=0
success_count=0
total_reward=0
second=3
number = Data_Reader(second).count
agent=DQNAgent(number, number)
file_path = "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx"
start_row = 2


def add_success_rate(file_path, success_rate, start_row):
    # 엑셀 파일 열기
    workbook = openpyxl.load_workbook(file_path)

    # 원하는 시트 선택 (시트 이름은 필요에 따라 수정)
    sheet = workbook.active  # 기본 시트 선택

    # 성공률 데이터를 C 열에 저장
    sheet.cell(row=start_row, column=3, value=success_rate)

    # 엑셀 파일 저장
    workbook.save(file_path)

    # 엑셀 파일 닫기
    workbook.close()


for e in range(0, num_of_episodes):
    state=env.reset(second)
    state=np.reshape(state,[1,number])

    #Initialize variable
    terminated=False
    
    success_count=0
    for timestep in range(timesteps_per_episode):
        print("State::::",state)

        #Run Action
        action=agent.act(state)


        next_state, reward, terminated, info= env.step(action,second)
        total_reward+=reward
        ep_reward[count]=total_reward
        if(reward==2 or reward==3):
            success_count+=1

        print("Success Count,rewards:::",success_count,reward,len(rewards))
        success_rate = ((100*success_count)/(count+1))
        print(success_rate)
        add_success_rate(file_path, success_rate, start_row)
        start_row += 1

        #next state
        next_state=np.reshape(next_state,[1,number])
        agent.store(state,action, reward, next_state, terminated)
        state=next_state
        print("Next State::",state)

        if terminated:
            agent.alighn_target_model()
            break
        
        if len(agent.memory) > agent.batch_size:
            agent.retrain(number)
        
        count+=1
       
    rewards.append((100*success_count)/(timesteps_per_episode))

    
    
    #while not terminated_q:
    count+=1
    second+=3
    number = Data_Reader(second).count

    agent.state_size=number
    agent.action_size=number
    agent.rebuild_model(agent.state_size, agent.action_size)
    #reset the environment
    #state=env.reset(second)
    
print("Rewards::::::::::::",rewards)

