import numpy as np

# Example numpy array
my_array = np.array([1, 2, 3, 4, 5])


# Create a new column vector containing [0]
zero_column = np.zeros((my_array.shape[0], 1))


my_array = np.concatenate((my_array, zero_column), axis=1)
print(my_array)
