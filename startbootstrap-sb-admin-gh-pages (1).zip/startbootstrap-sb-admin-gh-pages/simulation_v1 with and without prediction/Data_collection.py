import Cpu_num
import X_num
import Y_num
import Speed_num
import numpy as np
import time

class Data_Reader():
    def __init__(self,input_num):
        self.input_num = input_num

        cpu_reader = Cpu_num.Cpu_Reader(input_num)
        self.Cpu_list = cpu_reader.get_result_dict().values()
        self.Cpu_list = [x for x in self.Cpu_list if x != '']


        # Y_num.Y_Reader 객체 생성 및 결과 리스트 가져오기
        y_reader = Y_num.Y_Reader(input_num)
        self.Y_list = y_reader.get_result_dict().values()
        self.Y_list = [x for x in self.Y_list if x != '']

        # X_num.X_Reader 객체 생성 및 결과 리스트 가져오기
        x_reader = X_num.X_Reader(input_num)
        self.X_list = x_reader.get_result_dict().values()
        self.X_list = [x for x in self.X_list if x != '']

        # Speed_num.Speed_Reader 객체 생성 및 결과 리스트 가져오기
        speed_reader = Speed_num.Speed_Reader(input_num)
        self.Speed_list = speed_reader.get_result_dict().values()
        self.Speed_list = [x for x in self.Speed_list if x != '']

        self.count = len(self.Cpu_list)

#
#     def print_values(self):
#         print("Cpu_list:", self.Cpu_list)
#         print("Y_list:", self.Y_list)
#         print("X_list:", self.X_list)
#         print("Speed_list:", self.Speed_list)
#         print("count:", self.count)
#
# data_reader = Data_Reader(4)
# data_reader.print_values()