from gym import Env
from gym.spaces import Discrete, Box
import numpy as np
import random
import matplotlib.pyplot as plt
from foggateway import FogGateway
from clusterhead import PublicTransportation
from vehicle import Vehicle
from clustermember import ClusterMember
from Data_collection import Data_Reader
import Cpu_num
import openpyxl
class CreateClusEnv(Env):
    # Initializing the spaces
    def __init__(self):
        # In order to reset the vehicles to init states
        self.input_second = 3
        self.fog_gateway = self.set_fog_gateway(self.input_second)

        # For ClusterHeads CPU_util
        self.chs_cpu_util = []
        for x in range(len(self.fog_gateway.get_clus_heads())):
            self.chs_cpu_util.append(self.fog_gateway.get_clus_heads()[x].get_fog_cpu_util())

        # Actions that we can take
        self.action_space = list(range(0, 2))

        # set start state of fog_gateway
        self.chs_cpu_util.append(0)
        self.chs_cpu_util.append(self.fog_gateway.get_task_workload())
        self.state = self.chs_cpu_util

        self.iteration = 5

    def save_to_excel(self,file_path, data_list):
        # 엑셀 파일 불러오기
        wb = openpyxl.load_workbook(file_path)
        # 첫 번째 시트 선택
        sheet = wb.active
        # 현재 사용되는 행 번호 확인
        current_row = sheet.max_row + 1

        # 데이터를 두 번째 열에 저장
        for data in data_list:
            #cell = sheet.cell(row=current_row, column=2, value=data)
            sheet.cell(row=current_row, column=2, value=data)
            current_row += 1

        # 변경된 내용 저장
        wb.save(file_path)
        wb.close()
    # run whenever you take a step within your environment
    # With Prediciton of future position
    def step(self, action,second):
        # Action will be selected cluster head

        # Future positon of Cluster Head
        self.fog_gateway.get_clus_heads()[action].get_veh().set_future_pos(self.fog_gateway.get_dead_task())
        future_pos_ch = self.fog_gateway.get_clus_heads()[action].get_veh().get_future_pos()
        current_pos_ch = self.fog_gateway.get_clus_heads()[action].get_veh().get_position()
        file_path = "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx"

        # Calculate Reward
        if (self.euclidean(current_pos_ch, self.fog_gateway.get_position()) > self.fog_gateway.get_trans_range()):
            print("Selected vehicle is out of range::", action)
            cpu_reader = Cpu_num.Cpu_Reader(second)
            result_dict = cpu_reader.get_result_dict()
            print(list(result_dict.keys())[action])
            reward = -3
            data_to_save = [list(result_dict.keys())[action]]

            # save_to_excel() 함수를 사용하여 data_to_save를 엑셀 파일에 저장합니다.
            self.save_to_excel(file_path, data_to_save)
        elif (self.euclidean(future_pos_ch, self.fog_gateway.get_position()) > self.fog_gateway.get_trans_range()):
            print("Selected vehicle will not be in a range after processing depend on predicted position::", action)
            cpu_reader = Cpu_num.Cpu_Reader(second)
            result_dict = cpu_reader.get_result_dict()
            print(list(result_dict.keys())[action])
            reward = -2
            data_to_save = [list(result_dict.keys())[action]]

            # save_to_excel() 함수를 사용하여 data_to_save를 엑셀 파일에 저장합니다.
            self.save_to_excel(file_path, data_to_save)
        elif (self.fog_gateway.get_clus_heads()[action].get_fog_cpu_util() > 90):
            print("Selected vehicle is overloaded::",action)
            cpu_reader = Cpu_num.Cpu_Reader(second)
            result_dict = cpu_reader.get_result_dict()
            print(list(result_dict.keys())[action])
            reward = -1
            data_to_save = [list(result_dict.keys())[action]]

            # save_to_excel() 함수를 사용하여 data_to_save를 엑셀 파일에 저장합니다.
            self.save_to_excel(file_path, data_to_save)
        else:
            #tmp_ch_util = self.fog_gateway.get_clus_heads()[action].get_fog_cpu_util()
            #deadline_task = self.fog_gateway.get_dead_task()
            reward = 3
            #self.fog_gateway.get_clus_heads()[action].set_fog_cpu_util(tmp_ch_util + deadline_task)
            print("Selected Vehicle is a good one and in a range of fog gateway after predicted positon::", action)
            cpu_reader = Cpu_num.Cpu_Reader(second)
            result_dict = cpu_reader.get_result_dict()
            print(list(result_dict.keys())[action])
            data_to_save = [list(result_dict.keys())[action]]

            # save_to_excel() 함수를 사용하여 data_to_save를 엑셀 파일에 저장합니다.
            self.save_to_excel(file_path, data_to_save)

        self.iteration -= 1

        # iteration for each episode
        if self.iteration <= 0:
            done = True
        else:
            done = False

        

        # next state of another task workload
        self.fog_gateway.set_task_workload(random.randint(11, 15))
        self.fog_gateway.set_dead_task(self.fog_gateway.get_task_workload() - 10)
        self.state = self.chs_cpu_util


        # Set placeholder for info
        info = {}
        return self.state, reward, done, info

    # going to visualize or not
    def render(self, ep_reward, total_num, label):
        x_axis = []
        y_axis = ep_reward
        for x in range(0, total_num):
            x_axis.append((x + 1))

        # plotting the points
        plt.plot(x_axis, y_axis, label="Deep Q Network without prediction")

        # naming the x axis
        plt.xlabel('No. of Tasks')
        # naming the y axis
        plt.ylabel(label)

        # giving a title
        plt.title("Testing")

        # function to show the plot
        plt.show()

    # rest the environment
    def reset(self,input):

        # reset the fog gateway
        #self.input_second += 5
        self.fog_gateway.set_clus_heads(self.cluster_head_array(input))

        # For ClusterHeads CPU_util
        self.chs_cpu_util = []
        for x in range(len(self.fog_gateway.get_clus_heads())):
            self.chs_cpu_util.append(self.fog_gateway.get_clus_heads()[x].get_fog_cpu_util())

        # reset state of fog_gateway
        self.state = self.chs_cpu_util

        self.iteration = 5
        return self.state

    # Manhattan distance
    def manhattan(self, clu_head, veh):
        return sum(abs(val1 - val2) for val1, val2 in zip(clu_head, veh))

    # Euclidean distance
    def euclidean(self, veh, fg):
        return ((((veh[0] - fg[0]) ** 2) + ((veh[1] - fg[1]) ** 2)) ** 0.5)
   
    def cluster_head_array(self, input_num):
        ch_array = []
        car_count = Data_Reader(input_num).count
        car_velocity=Data_Reader(input_num).Speed_list
        car_x_list=Data_Reader(input_num).X_list
        car_y_list=Data_Reader(input_num).Y_list
        car_cpu=Data_Reader(input_num).Cpu_list
        for index in range(car_count):
            velocity = car_velocity[index]
            position = [car_x_list[index], car_y_list[index]]
            direction = 'N'
            # VEHICLE PARA (velocity, direction, dist_ch, dist_fg, position)
            vh = Vehicle(velocity, direction, 10, 10, position)
            core = random.choice([4, 8])
            ram = random.choice([8, 16])
            cpu_util = car_cpu[index]
            # CLUSTER HEAD PARA (fog_mips, fog_core, fog_ram, fog_cpu_util, veh, clu_mem)
            ch = PublicTransportation(10, core, ram, cpu_util, vh, [])
            ch_array.append(ch)
        return ch_array

    def set_fog_gateway(self, input_num):
        clus_heads = self.cluster_head_array(input_num)  # 고쳐라
        trans_range = random.choice([0, 1000])  # 1000을 1000-1100 사이로 변경해보면서 나중에 0 변경
        task_workload = random.randint(11, 15)
        deadline_task = task_workload - 10
        fg_pos = self.fg_position(np.array([random.randint(-50, 50), random.randint(-50, 50)])) # basestation 좌표
        task_pos = np.array([random.randint(-150, 150), random.randint(-150, 150)])
        # FOG_GATEWAY PARA (trans_range, task_workload,task_position, dead_task, clus_heads, position)
        fg = FogGateway(trans_range, task_workload, task_pos, deadline_task, clus_heads, fg_pos)
        return fg

    def fg_position(self, pos):
        if ((pos[0] <= 20 and pos[0] >= -20) or (pos[1] <= 20 and pos[1] >= -20)):
            pos = self.fg_position(np.array([random.randint(-50, 50), random.randint(-50, 50)]))
        return pos