# 1순위 차량 받아와 챠량 정보를 나머지.xlsx에 저장
import openpyxl

# 엑셀 상 알파벳 숫자로 처리
def convert_alphabet_to_number(alphabet):
    base = ord('A')
    value = 0
    for char in alphabet:
        value = value * 26 + (ord(char) - base + 1)
    return value


if __name__ == "__main__":
    workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    sheet = workbook.active
    coordinate_workbook = openpyxl.load_workbook(
        'C:/Users/황지혁/Desktop/4intersection (2)/4intersection/4intersection/4intersection/intersection.xlsx')

    row_number = 3
    real_result = []

    for row in sheet.iter_rows(min_row=2, min_col=2, max_col=2):
        cell = row[0]
        if cell.value is None:
            break

        result_list = []

        prefix = cell.value.split("_")[0]
        if prefix == 'car':
            current = 'taxi_' + str(convert_alphabet_to_number(cell.value.split("_")[-1]))
        elif prefix == 'bus':
            current = 'bus_' + str(convert_alphabet_to_number(cell.value.split("_")[-1]))

        parts = current.split('_')

        # taxi
        if parts[0] == 'taxi':
            # 엑셀 상 알파벳 > 숫자로 변환
            number_taxi = int(parts[-1])
            if coordinate_workbook.worksheets[0].cell(row=row_number, column=number_taxi + 1).value is not None:
                taxi_cpu = int(
                    coordinate_workbook.worksheets[0].cell(row=row_number, column=number_taxi + 1).value)
                taxi_coordinateX = int(
                    coordinate_workbook.worksheets[1].cell(row=row_number, column=number_taxi + 1).value)
                taxi_coordinateY = int(
                    coordinate_workbook.worksheets[2].cell(row=row_number, column=number_taxi + 1).value)
                taxi_speed = round(
                    coordinate_workbook.worksheets[3].cell(row=row_number, column=number_taxi + 1).value, 1)

                result_list.append(current)
                result_list.append(taxi_cpu)
                result_list.append(taxi_coordinateX)
                result_list.append(taxi_coordinateY)
                result_list.append(taxi_speed)
            else:
                result_list = []

        # bus
        elif parts[0] == 'bus':
            # 엑셀 상 알파벳 > 숫자로 변환
            number_bus = int(parts[-1])
            if coordinate_workbook.worksheets[4].cell(row=row_number, column=number_bus + 1).value is not None:
                bus_cpu = int(
                    coordinate_workbook.worksheets[4].cell(row=row_number, column=number_bus + 1).value)
                bus_coordinateX = int(
                    coordinate_workbook.worksheets[5].cell(row=row_number, column=number_bus + 1).value)
                bus_coordinateY = int(
                    coordinate_workbook.worksheets[6].cell(row=row_number, column=number_bus + 1).value)
                bus_speed = round(
                    coordinate_workbook.worksheets[7].cell(row=row_number, column=number_bus + 1).value, 1)

                result_list.append(current)
                result_list.append(bus_cpu)
                result_list.append(bus_coordinateX)
                result_list.append(bus_coordinateY)
                result_list.append(bus_speed)
            else:
                result_list = []

        row_number += 1

        real_result.append(result_list)

    print(real_result)

    file_path = "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/나머지.xlsx"
    output_workbook = openpyxl.load_workbook(file_path)
    output_sheet = output_workbook.active

    for i in range(len(real_result)):
        if not real_result[i]:
            for j in range(5):
                output_sheet.cell(row=i + 2, column=j + 2, value=0)
        else:
            for j in range(5):
                output_sheet.cell(row=i + 2, column=j + 2, value=real_result[i][j])

    # 엑셀 파일 저장
    output_workbook.save(file_path)

    # 파일 닫기
    output_workbook.close()