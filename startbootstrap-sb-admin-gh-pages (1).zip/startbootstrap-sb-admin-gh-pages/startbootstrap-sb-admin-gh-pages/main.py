import openpyxl
from flask import Flask, render_template

# 1순위 차량 모든 정보 담긴 엑셀 받아옴 (가장 최근 기준 시각까지)
def read_excel_data(time):
    file_path = "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/나머지.xlsx"
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active

    table_list = []
    current_row = 2

    while current_row <= time:
        row = sheet.cell(row=current_row, column=2).value, sheet.cell(row=current_row, column=3).value, sheet.cell(row=current_row, column=4).value, sheet.cell(row=current_row, column=5).value, sheet.cell(row=current_row, column=6).value
        table_list.append(row)
        current_row += 1

    # car_list : 기준시각 택시/버스/총 차량 대수
    car_list = []
    for col_number in range(17, 20):
        cell_value = sheet.cell(row=time, column=col_number).value
        car_list.append(cell_value)

    return table_list, car_list

# 엑셀에 접근해 가장 최근 기준시각의 2,3순위 차량 정보 받아옴
def read_excel_2nd3rd(time):
    file_path = "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/나머지.xlsx"
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active

    table_list = []
    current_row = time

    if current_row < 2 or current_row > sheet.max_row:
        return table_list

    for column in range(7, 17):
        cell_value = sheet.cell(row=current_row, column=column).value
        table_list.append(cell_value)

    return table_list


# Flask 앱 생성
app = Flask(__name__, template_folder='templates')


@app.route('/')
def index():
    workbook = openpyxl.load_workbook("C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    sheet = workbook.active

    # accuracy_list : 정확도 저장 리스트
    accuracy_list = []
    for row in sheet.iter_rows(min_row=2, min_col=3, max_col=3):
        cell = row[0]
        if cell.value is None:
            break
        accuracy_list.append(int(cell.value))

    row = 2
    while sheet.cell(row=row, column=2).value is not None:
        row += 1
    time = row - 1

    # 1순위 모든 정보의 table_list & 기준시각에 대한 차량 정보의 others
    table_list, car_list = read_excel_data(time)
    others = read_excel_2nd3rd(time)

    firstList = table_list[-1]
    secondList = others[:5]
    thirdList = others[5:]

    return render_template('index.html', accuracy=accuracy_list, time=time, firstList=firstList, secondList=secondList, thirdList=thirdList, table_list=table_list, car_list=car_list)


@app.route('/charts.html')
def charts():
    workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    sheet = workbook.active

    accuracy_list = []
    for row in sheet.iter_rows(min_row=2, min_col=3, max_col=3):
        cell = row[0]
        if cell.value is None:
            break
        accuracy_list.append(int(cell.value))

    return render_template('charts.html', accuracy=accuracy_list)

@app.route('/tables.html')
def tables():
    workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    sheet = workbook.active

    row = 2
    while sheet.cell(row=row, column=2).value is not None:
        row += 1
    time = row - 1
    table_list, _ = read_excel_data(time)

    return render_template('tables.html', table_list=table_list)

@app.route('/selected.html')
def selected():
    workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    sheet = workbook.active

    row = 2
    while sheet.cell(row=row, column=2).value is not None:
        row += 1
    time = row - 1
    table_list, _ = read_excel_data(time)

    # 1순위 모든 정보의 table_list & 기준시각에 대한 차량 정보의 others
    table_list, car_list = read_excel_data(time)
    others = read_excel_2nd3rd(time)

    firstList = table_list[-1]
    secondList = others[:5]
    thirdList = others[5:]

    return render_template('selected.html', table_list=table_list, time=time, firstList=firstList, secondList=secondList, thirdList=thirdList, car_list=car_list)

@app.route('/login.html')
def login():
    return render_template('login.html')

@app.route('/password.html')
def password():
    return render_template('password.html')

@app.route('/register.html')
def register():
    return render_template('register.html')

@app.route('/traffic.html')
def traffic():
    return render_template('traffic.html')

@app.route('/mobile.html')
def mobile():
    return render_template('mobile.html')


if __name__ == '__main__':
    app.run()