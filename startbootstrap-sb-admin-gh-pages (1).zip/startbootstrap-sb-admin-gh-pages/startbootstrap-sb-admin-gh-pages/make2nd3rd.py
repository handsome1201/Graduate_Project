# cpu 높은 상위 2개 미리 뽑아 나머지.xlsx에 저장
import openpyxl

# 2,3순위 차량 정보 리스트로 추출
def make_carinfo_list(target, time):
    coordinate_workbook = openpyxl.load_workbook(
        'C:/Users/황지혁/Desktop/4intersection (2)/4intersection/4intersection/4intersection/intersection.xlsx')
    carinfo_list = []
    parts = target.split('_')

    # taxi
    if target.startswith('taxi'):
        number_taxi = int(parts[-1])
        if coordinate_workbook.worksheets[1].cell(row=time, column=number_taxi).value is not None:
            taxi_cpu = int(
                coordinate_workbook.worksheets[0].cell(row=time, column=number_taxi).value)
            taxi_coordinateX = int(
                coordinate_workbook.worksheets[1].cell(row=time, column=number_taxi).value)
            taxi_coordinateY = int(
                coordinate_workbook.worksheets[2].cell(row=time, column=number_taxi).value)
            taxi_speed = round(
                coordinate_workbook.worksheets[3].cell(row=time, column=number_taxi).value, 1)

            # carinfo_list = [차량정보, cpu, x좌표, y좌표, 속력]
            carinfo_list.append(parts[0] + '_' + str(number_taxi))
            carinfo_list.append(taxi_cpu)
            carinfo_list.append(taxi_coordinateX)
            carinfo_list.append(taxi_coordinateY)
            carinfo_list.append(taxi_speed)
        else:
            carinfo_list.append(None)
            print("Value is none")

    # bus
    elif parts[0] == 'bus':
        number_bus = int(parts[-1])
        if coordinate_workbook.worksheets[4].cell(row=time, column=number_bus).value is not None:
            bus_cpu = int(
                coordinate_workbook.worksheets[4].cell(row=time, column=number_bus).value)
            bus_coordinateX = int(
                coordinate_workbook.worksheets[5].cell(row=time, column=number_bus).value)
            bus_coordinateY = int(
                coordinate_workbook.worksheets[6].cell(row=time, column=number_bus).value)
            bus_speed = round(
                coordinate_workbook.worksheets[7].cell(row=time, column=number_bus).value, 1)

            carinfo_list.append(parts[0] + '_' + str(number_bus))
            carinfo_list.append(bus_cpu)
            carinfo_list.append(bus_coordinateX)
            carinfo_list.append(bus_coordinateY)
            carinfo_list.append(bus_speed)
        else:
            carinfo_list.append(None)
            print("Value is none")

    return carinfo_list



if __name__ == "__main__":
    # 최적 차량 정보 있는 엑셀
    result_workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    result_sheet = result_workbook.active

    # 나머지.xlsx 파일 열기
    output_workbook = openpyxl.load_workbook(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/나머지.xlsx")
    output_sheet = output_workbook.active

    # 결과.xlsx에서 B열 값을 기준으로 처리 (일단 결과.xlsx이 74초까지 채워져있으니 74초(max_row)까지 돌리기 - 나중에 더 채우도록 수정)
    for current_row_number, row in enumerate(result_sheet.iter_rows(min_row=2, max_row=74, min_col=2), start=2):
        cell = row[0]
        if cell.value is None:
            break
        best_car = cell.value

        intersection_workbook = openpyxl.load_workbook(
            'C:/Users/황지혁/Desktop/4intersection (2)/4intersection/4intersection/4intersection/intersection.xlsx')

        # CPU 값 저장을 위한 빈 리스트 초기화
        cpu_values = []

        cpu_values_0 = 0
        cpu_values_4 = 0

        for sheet_index in [0, 4]:
            sheet = intersection_workbook.worksheets[sheet_index]
            for col_number in range(2, sheet.max_column + 1):
                cell = sheet.cell(row=row[0].row, column=col_number)
                if cell.value is not None:
                    cpu_values.append((int(cell.value), sheet_index, col_number))
                    if sheet_index == 0:
                        cpu_values_0 += 1
                    else:
                        cpu_values_4 += 1

        # CPU 값 상위 2개 선택
        cpu_values.sort(key=lambda x: x[0], reverse=True)
        top_2_cpu_values = cpu_values[:2]

        # top_2_cpu_values의 각 값과 시트 번호를 구분
        for index, (value, sheet_index, col_number) in enumerate(top_2_cpu_values):
            sheet_name = 'taxi' if sheet_index == 0 else 'bus'
            cell_value = f"{sheet_name}_{col_number}"
            carinfo_list = make_carinfo_list(cell_value, current_row_number)

            # 2순위 : current_row_number행 2열부터 6열까지 저장
            if index % 2 == 0:
                for i, data in enumerate(carinfo_list):
                    output_sheet.cell(row=current_row_number, column=7 + i, value=data)
            # 3순위 : current_row_number행 7열부터 11열까지 저장
            else:
                for i, data in enumerate(carinfo_list):
                    output_sheet.cell(row=current_row_number, column=12 + i, value=data)

        # 택시/버스/총 대수 엑셀에 저장
        output_sheet.cell(row=current_row_number, column=17, value=cpu_values_0)
        output_sheet.cell(row=current_row_number, column=18, value=cpu_values_4)
        output_sheet.cell(row=current_row_number, column=19, value=cpu_values_0 + cpu_values_4)

        print(f"{current_row_number} 완료")


    # 결과 저장
    result_workbook.save(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/결과.xlsx")
    output_workbook.save(
        "C:/Users/황지혁/Desktop/RealMEC/startbootstrap-sb-admin-gh-pages/simulation_v1 with and without prediction/파일_17/나머지.xlsx")